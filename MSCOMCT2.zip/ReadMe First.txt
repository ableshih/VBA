Please read thoroughly the associated web page before attempting to use this add-in
http://www.gmayor.com/ManyToOne.htm 

Either use the EXE installer (which will remove earlier versions) or manually put the template in the Word Startup folder.

Note that the EXE installer will attempt to put the template in the default startup folder. If you have moved the location of the startup folder, change the path at the prompt to reflect the new location.

The zip also includes the example files used on the web site. These files are not extracted when installing using the EXE installer.


Microsoft Windows Common Controls

The add in uses the Microsoft Windows Common Controls provided in the file mscomct2.ocx (which does not work in 64 bit versions of Office).

If the file is missing from the appropriate folder (or is in the wrong folder) or is not registered, the add-in will not run, but will produce an error message.

If missing extract the OCX file to the relevant folder (se below), then open a command prompt (as administrator in Windows Vista and Windows 7) from Windows Start > Run.


Windows 64 bit
In 64 bit versions of Windows, this file will be required in the folder C:\Windows\SysWOW64
In that command window, type regsvr32 "C:\Windows\SysWOW64\MSCOMCT2.OCX" and press Enter. You will get a  message that it is registered. Restart Word and see if it works now.

Windows 32 bit
In 32 bit versions of Windows, this file should be in the folder C:\Windows\System32
In that command window, type regsvr32 "C:\Windows\System32\mscomct2.ocx" and press Enter. You will get a  message that it is registered. Restart Word and see if it works now.

More complete instructions for installing MSCOMCT2.OCX, with illustrations are to be found in the accompanying PDF file.

Graham Mayor 2012